const form = document.getElementById('form');
const pesoInput = document.getElementById('peso');
const historial = document.getElementById('historial');

function cargarHistorial() {
  historial.innerHTML = '';
  const datos = JSON.parse(localStorage.getItem('pesos')) || [];
  datos.forEach(registro => {
    const li = document.createElement('li');
    li.textContent = `${registro.fecha}: ${registro.peso} kg`;
    historial.appendChild(li);
  });
}

form.addEventListener('submit', e => {
  e.preventDefault();
  const peso = parseFloat(pesoInput.value);
  const fecha = new Date().toLocaleDateString();
  const nuevoRegistro = { fecha, peso };

  const datos = JSON.parse(localStorage.getItem('pesos')) || [];
  datos.unshift(nuevoRegistro);
  localStorage.setItem('pesos', JSON.stringify(datos));

  pesoInput.value = '';
  cargarHistorial();
});

cargarHistorial();
